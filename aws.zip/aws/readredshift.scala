package org.inceptez.spark.aws

import org.apache.spark.sql._


object readredshift
{
  def main(args:Array[String])
  {
    val spark = SparkSession
      .builder()
      .master("local")
      .appName("s3read")
      //.config("hive.metastore.uris", "thrift://localhost:9083")
      //.config("spark.sql.warehouse.dir", "/user/hive/warehouse")   
      //.enableHiveSupport()
      .getOrCreate()
      spark.sparkContext.setLogLevel("ERROR")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.access.key", "AKIAJUODNNBKD2LYFABA")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", "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")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.endpoint", "s3.amazonaws.com")
      //spark.sparkContext.hadoopConfiguration.set("com.amazonaws.services.s3.enableV4", "true")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
      
      val df1 = spark.read.format("com.databricks.spark.redshift")
      .option("url", "jdbc:redshift://redshift-cluster-1.cdnd7lzbkma0.us-east-1.redshift.amazonaws.com:5439/dev?user=awsuser&password=Inside123$")
      .option("forward_spark_s3_credentials",true)
      //.option("jdbcdriver","org.postgresql.Driver")
      .option("dbtable", "table1").option("tempdir", "s3a://iz.databricks/tempdir/").load()
      
       val df = spark.read.option("header","false")
       .option("delimiter", ",")
       .option("inferschema", "true")
       //.csv("s3a://iz-bucket2/profile/txns")
       .csv("s3a://iz.databricks/tempdir/cust_data1") // N Virginia region
       .toDF("id","name","age")
       df.show(false)
       
       /*df.write.format("com.databricks.spark.redshift")
      .option("url", "jdbc:redshift://redshift-cluster-1.cdnd7lzbkma0.us-east-1.redshift.amazonaws.com:5439/dev?user=awsuser&password=Inside123$")
      .option("forward_spark_s3_credentials",true)
      //.option("jdbcdriver","org.postgresql.Driver")
      .option("dbtable", "custtbl").option("tempdir", "s3a://iz.databricks/tempdir/").mode("append").save()*/
       //s3://inceptez-we28/custinfo/sample_data.txt
       
         import org.apache.spark.sql.functions._;
       import spark.sqlContext.implicits._;
    val curts=Seq(1).toDF().withColumn("current_timestamp",current_timestamp).select(date_format(col("current_timestamp"),"yyyyMMddHHMMSS")).take(1)(0)(0).toString
       df1.write.option("mode", "overwrite").csv("s3a://iz.bucket1/rds_retail/custinfo_"+curts);
  println("S3 Object is created")
       
  }
       
}