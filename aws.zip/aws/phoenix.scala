package org.inceptez.spark.aws
import org.apache.spark.sql._
import org.apache.spark.sql.SQLContext
//import org.apache.phoenix.spark._

object phoenix {

  def main(args:Array[String])
  {
/*    val spark = SparkSession
      .builder()
      .master("local")
      .appName("phoenix")
      //.config("hive.metastore.uris", "thrift://localhost:9083")
      //.config("spark.sql.warehouse.dir", "/user/hive/warehouse")   
      //.enableHiveSupport()
      .getOrCreate()
*/
//val dfphoenix = spark.sqlContext.load(
//  "org.apache.phoenix.spark",
//  Map("table" -> "WEB_STAT", "zkUrl" -> "localhost:2181")
//)

//dfphoenix.show();
//dfphoenix.filter(dfphoenix("COL1") === "test_row_1" && dfphoenix("ID") === 1L).select(dfphoenix("ID"))

import org.apache.hadoop.conf.Configuration
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
//import org.apache.phoenix.spark._

val configuration = new Configuration()
// Can set Phoenix-specific settings, requires 'hbase.zookeeper.quorum'

val sc = new SparkContext("local", "phoenix-test")
val sqlContext = new SQLContext(sc)

// Loads the columns 'ID' and 'COL1' from TABLE1 as a DataFrame
//val df = sqlContext.phoenixTableAsDataFrame("SAMPLE1", Array("CUSTID", "NAME","AGE"), conf = configuration)
//df.show

//import org.apache.phoenix.spark._
val df1 = sqlContext.read.format("jdbc").options(Map("driver" -> "org.apache.phoenix.jdbc.PhoenixDriver",
    "url" -> "jdbc:phoenix:localhost:2181", "dbtable" -> "SAMPLE1")).load();
df1.show();    
}
}