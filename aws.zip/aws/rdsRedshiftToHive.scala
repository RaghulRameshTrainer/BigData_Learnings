package org.inceptez.spark.aws

import org.apache.spark.sql._
//spark-submit --jars file:///home/hduser/postgresql-42.2.18.jar
// --class org.inceptez.spark.aws.rdsRedshiftToHive /home/hduser/rdsleanjar.jar
// Usecase 2 - load public cloud RDS,REDSHIFT to private cloud HIVE TABLE
object rdsRedshiftToHive
{
  def main(args:Array[String])
  {
    val spark = SparkSession
      .builder()
      .master("local")
      .appName("load public cloud RDS,REDSHIFT to private cloud HIVE TABLE")
      .config("hive.metastore.uris", "thrift://localhost:9083")
      .config("spark.sql.warehouse.dir", "/user/hive/warehouse")   
      .enableHiveSupport()
      .getOrCreate()
      spark.sparkContext.setLogLevel("ERROR")
      
      
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.access.key", "AKIAJGHAAH76T2HWZSRA")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", "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")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.endpoint", "s3.amazonaws.com")
      spark.sparkContext.hadoopConfiguration.set("com.amazonaws.services.s3.enableV4", "true")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
      
      /*val df1 = spark.read.format("com.databricks.spark.redshift")
      .option("url", "jdbc:redshift://redshift-cluster-1.cfpvjrshobcf.us-east-2.redshift.amazonaws.com:5439/dev?user=awsuser&password=Inside123$")
      .option("forward_spark_s3_credentials",true)
      //.option("jdbcdriver","org.postgresql.Driver")
      .option("dbtable", "table1").option("tempdir", "s3a://iz.databricks/tempdir/").load()*/
      
       /*val df = spark.read.option("header","false")
       .option("delimiter", ",")
       .option("inferschema", "true")
       //.csv("s3a://iz-bucket2/profile/txns")
       .csv("s3a://iz.databricks/tempdir/cust_data1") // N Virginia region
       .toDF("id","name","age")
       df.show(false)*/
       //val customquery="(select * from healthcare.drugs where loaddt='01-OCT-20') tblquery" 
      println("Connecting to PostGre")
      val lddt="01-OCT-20";
    
      val customquery=s"(select * from healthcare.drugs where loaddt='$lddt') tblquery"
      
      println(customquery)

      val dfdrugs = spark.read.format("jdbc").option("url", "jdbc:postgresql://inceptezdb.cqeltditr1oc.us-east-1.rds.amazonaws.com:5432/izdb").
option("driver", "org.postgresql.Driver").option("dbtable", customquery).option("user", "postgres").
option("password", "postgres123").load()
println("Data from RDS Postgres")
      
      dfdrugs.cache();
    println("Data sample from Postgre")
      dfdrugs.show(5,false)  
      dfdrugs.na.drop.dropDuplicates().createOrReplaceTempView("postgresdrugs")

      println("Connecting to Redshift")
       
      val dfpatients = spark.read.format("com.databricks.spark.redshift")
      .option("url", "jdbc:redshift://redshift-cluster-1.cdnd7lzbkma0.us-east-1.redshift.amazonaws.com:5439/dev?user=awsuser&password=Inside123$")
      .option("forward_spark_s3_credentials",true)
      //.option("jdbcdriver","org.postgresql.Driver")
      .option("dbtable", "patients").option("tempdir", "s3a://iz.databricks/tempdir/").load()
      
      println("Data from RedShift")
      dfpatients.cache()
      println("Data sample from Redshift")
      dfpatients.show(5,false)
      dfpatients.na.drop.dropDuplicates().createOrReplaceTempView("redshiftpatients")
      
      val widedataDF=spark.sql("""select d.*,p.* from postgresdrugs d inner join redshiftpatients p on d.uniqueid=p.drugid""")
      widedataDF.show(5,false)
      widedataDF.write.mode("overwrite").partitionBy("loaddt").saveAsTable("default.patient_drugs_part")
      println("Data loaded to On Premise Hive Table ")
      spark.sql("""select * from patient_drugs_part""").show(5,false)
      
      println("Writing to Postgres")

val prop=new java.util.Properties();
prop.put("user", "root")
prop.put("password", "root")
prop.put("driver","org.postgresql.Driver")

widedataDF.write.mode("overwrite").jdbc("jdbc:postgresql://inceptezdb.cqeltditr1oc.us-east-1.rds.amazonaws.com:5432/izdb","patient_drugs_part",prop)
  }
       
}


















