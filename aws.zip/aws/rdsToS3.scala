package org.inceptez.spark.aws

import org.apache.spark.sql._

//spark-submit --jars file:///home/hduser/postgresql-42.2.18.jar --master spark://localhost:7077
// --class org.inceptez.spark.aws.rdsToS3 /home/hduser/rdsToS3leanjar.jar

object rdsToS3
{
  def main(args:Array[String])
  {
    val spark = SparkSession
      .builder()
      //.master("local")
      .appName("EMR RDS to S3 Public Cloud")
      //.config("hive.metastore.uris", "thrift://localhost:9083")
      //.config("spark.sql.warehouse.dir", "/user/hive/warehouse")   
      //.enableHiveSupport()
      .getOrCreate()
      spark.sparkContext.setLogLevel("ERROR")
      
      
      /*val df1 = spark.read.format("com.databricks.spark.redshift")
      .option("url", "jdbc:redshift://redshift-cluster-1.cfpvjrshobcf.us-east-2.redshift.amazonaws.com:5439/dev?user=awsuser&password=Inside123$")
      .option("forward_spark_s3_credentials",true)
      //.option("jdbcdriver","org.postgresql.Driver")
      .option("dbtable", "table1").option("tempdir", "s3a://iz.databricks/tempdir/").load()*/
      
       /*val df = spark.read.option("header","false")
       .option("delimiter", ",")
       .option("inferschema", "true")
       //.csv("s3a://iz-bucket2/profile/txns")
       .csv("s3a://iz.databricks/tempdir/cust_data1") // N Virginia region
       .toDF("id","name","age")
       df.show(false)*/

      val lddt=args(0);
      //val lddt="01-OCT-20" 
      val customquery=s"(select * from healthcare.drugs where loaddt='$lddt') tblquery"
      
      println(customquery)

      val dfdrugs = spark.read.format("jdbc").option("url", "jdbc:postgresql://inceptezdb.cqeltditr1oc.us-east-1.rds.amazonaws.com:5432/izdb").
option("driver", "org.postgresql.Driver").option("dbtable", customquery).option("user", "postgres").
option("password", "postgres123").load()
println("Data from RDS Postgres")
      
      dfdrugs.cache();
    dfdrugs.show(5,false)  
    dfdrugs.na.drop.createOrReplaceTempView("postgresdrugs")
           
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.access.key", "AKIAJGHAAH76T2HWZSRA")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", "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")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.endpoint", "s3.amazonaws.com")
      spark.sparkContext.hadoopConfiguration.set("com.amazonaws.services.s3.enableV4", "true")
      spark.sparkContext.hadoopConfiguration.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
       
  
       import org.apache.spark.sql.functions._;
       import spark.sqlContext.implicits._;
    val curts=Seq(1).toDF().withColumn("current_timestamp",current_timestamp).select(date_format(col("current_timestamp"),"yyyyMMddHHMMSS")).take(1)(0)(0).toString
       dfdrugs.write.option("mode", "overwrite").csv("s3a://iz.bucket1/rds_retail/drugsinfo_"+curts);
  println("S3 Object is created successfully")
      
       
  }
       
}